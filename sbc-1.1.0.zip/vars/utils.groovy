// vars/utils.groovy
import com.sbc.utils.ConfigLoader  // class from src/

def call() {
    echo 'utils.groovy: loaded'

    // 1) load config from resources via src class
    def cfg = ConfigLoader.loadConfig(this)
    echo "utils.groovy: config loaded -> ${cfg}"

    // 2) return a simple API for Jenkinsfiles
    return [
        getAppName : { -> cfg.appName },
        getDefaultEnv : { -> cfg.defaultEnv },
        getRegistry : { -> cfg.imageRegistry }
    ]
}
