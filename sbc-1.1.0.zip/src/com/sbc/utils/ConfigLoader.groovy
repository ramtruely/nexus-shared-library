package com.sbc.utils

class ConfigLoader implements Serializable {

    static Map loadConfig(script) {
        // script is the pipeline script (to use libraryResource/readJSON)
        def jsonText = script.libraryResource('config/app-config.json')
        script.echo "ConfigLoader: loaded JSON length=${jsonText.length()}"
        return script.readJSON(text: jsonText)
    }
}
